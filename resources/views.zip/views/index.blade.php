@extends('layout.base')

@pushOnce('head')
@endPushOnce

@section('body')
@endsection
